<?php
    include 'connect.php';
?>


<?php
require 'connect.php'; // This should contain your PDO connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Fetch form values safely
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $address = trim($_POST['address']);
    $role = $_POST['role'];

    if ($password !== $confirm_password) {
        die("Passwords do not match.");
    }

    $full_name = $first_name . ' ' . $last_name;
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    try {
        $pdo->beginTransaction();

        // Insert into role-specific table
        if ($role == 'conductor') {
            $stmt = $pdo->prepare("INSERT INTO conductor (first_name, last_name, email, phone, address) VALUES (?, ?, ?, ?, ?)");
        } elseif ($role == 'inspector') {
            $stmt = $pdo->prepare("INSERT INTO inspector (first_name, last_name, email, phone, address) VALUES (?, ?, ?, ?, ?)");
        } elseif ($role == 'admin') {
            $stmt = $pdo->prepare("INSERT INTO admin (first_name, last_name, email, phone, address) VALUES (?, ?, ?, ?, ?)");
        } else {
            die("Invalid role.");
        }

        $stmt->execute([$first_name, $last_name, $email, $phone, $address]);
        $reference_id = $pdo->lastInsertId();

        // Insert into user_account
        $stmt = $pdo->prepare("INSERT INTO user_account (full_name, username, password, role, reference_id) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$full_name, $email, $hashed_password, $role, $reference_id]);

        // Update the role table with user_account_id (if needed)
        $user_account_id = $pdo->lastInsertId();
        $updateTable = $role;
        $updateIdField = $role . "_id";

        $pdo->prepare("UPDATE $updateTable SET user_account_id = ? WHERE $updateIdField = ?")->execute([$user_account_id, $reference_id]);

        $pdo->commit();

        echo "Registration successful. You can now <a href='login.php'>login</a>.";
    } catch (Exception $e) {
        $pdo->rollBack();
        echo "Registration failed: " . $e->getMessage();
    }
}
?>