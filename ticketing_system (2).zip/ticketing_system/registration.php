<?php
include 'connect.php';
$success = "";
$error = "";

try {
    // Create PDO connection
    $pdo = new PDO("mysql:host=localhost;dbname=ticketing_system", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $address = trim($_POST['address']);
    $role = $_POST['role'];

    if ($password !== $confirm_password) {
        die("Passwords do not match.");
    }

    $full_name = $first_name . ' ' . $last_name;
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    try {
        $pdo->beginTransaction();

        // Insert into role-specific table
        if ($role == 'conductor') {
            $stmt = $pdo->prepare("INSERT INTO conductor (first_name, last_name, email, phone, address) VALUES (?, ?, ?, ?, ?)");
        } elseif ($role == 'inspector') {
            $stmt = $pdo->prepare("INSERT INTO inspector (first_name, last_name, email, phone, address) VALUES (?, ?, ?, ?, ?)");
        } elseif ($role == 'admin') {
            $stmt = $pdo->prepare("INSERT INTO admin (first_name, last_name, email, phone, address) VALUES (?, ?, ?, ?, ?)");
        } else {
            die("Invalid role.");
        }

        $stmt->execute([$first_name, $last_name, $email, $phone, $address]);
        $reference_id = $pdo->lastInsertId();

        // Insert into user_account
        $stmt = $pdo->prepare("INSERT INTO user_account (full_name, username, password, role, reference_id) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$full_name, $email, $hashed_password, $role, $reference_id]);

        $user_account_id = $pdo->lastInsertId();
        $updateTable = $role;
        $updateIdField = $role . "_id";

        // Update user_account_id in the role-specific table
        $pdo->prepare("UPDATE $updateTable SET user_account_id = ? WHERE $updateIdField = ?")->execute([$user_account_id, $reference_id]);

        $pdo->commit();

        echo "Registration successful. You can now <a href='login.php'>login</a>.";
    } catch (Exception $e) {
        $pdo->rollBack();
        echo "Registration failed: " . $e->getMessage();
    }
}
?>





<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Donsal's Portal Registration</title>
  <style>
    /* Base Reset */
    * {
      padding: 0;
      margin: 0;
      box-sizing: border-box;
      font-family: Arial, sans-serif;
    }
    body {
      position: relative;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      background-color: orange;
    }
    /* Back Button outside container */
    .back-btn-top {
      position: absolute;
      top: 20px;
      left: 20px;
      background-color: white;
      color: orange;
      border: none;
      border-radius: 24px;
      padding: 10px 20px;
      font-weight: bold;
      cursor: pointer;
      box-shadow: 0 2px 6px rgba(0,0,0,0.2);
      transition: background 0.3s, color 0.3s;
      text-decoration: none;
    }
    .back-btn-top:hover {
      background-color: #f1f1f1;
      color: darkorange;
    }
    /* Container */
    .container {
      display: flex;
      width: 80%;
      max-width: 900px;
      background: rgba(255, 255, 255, 0.9);
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      overflow: hidden;
    }
    .left-panel {
      flex: 1;
      padding: 30px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      background: #f8f9fa;
    }
    .left-panel .logo {
      width: 150px;
      margin-bottom: 20px;
    }
    .left-panel h1 {
      font-size: 20px;
      color: #333;
      text-align: center;
    }
    .right-panel {
      flex: 1;
      padding: 40px;
      background: #fff;
      position: relative;
    }
    h2 {
      text-align: center;
      margin-bottom: 25px;
      color: #333;
    }
    .form-group {
      margin-bottom: 15px;
    }
    .form-group label {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
      color: #555;
    }
    .form-control {
      width: 100%;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 5px;
      font-size: 14px;
    }
    .form-row {
      display: flex;
      gap: 15px;
    }
    .form-row .form-group {
      flex: 1;
    }
    .btn {
      width: 100%;
      padding: 12px;
      background: #007bff;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-weight: bold;
      margin-top: 10px;
      transition: background 0.3s;
    }
    .btn:hover {
      background: #0056b3;
    }
    .login-link {
      display: block;
      text-align: center;
      margin-top: 15px;
      color: #007bff;
      text-decoration: none;
    }
    .terms {
      margin: 15px 0;
      font-size: 12px;
      color: #666;
      display: flex;
      align-items: center;
    }
    .error-message {
      color: #dc3545;
      font-size: 12px;
      margin-top: 5px;
      display: none;
    }
    .success-message {
      color: #28a745;
      text-align: center;
      margin-bottom: 15px;
      display: none;
    }
    
  </style>
</head>
<body>

  <a href="landingpage.php" class="back-btn-top">←Back</a>

  <div class="container">
    <div class="left-panel">
      <img src="logo.png" alt="donsal" class="logo">
      <h1>Join Donsal's Express Corporation Today!</h1>
    </div>
    <div class="right-panel">
      <h2>Create Account</h2>
      <div id="successMessage" class="success-message"></div>
      <form id="registrationForm" method="POST" action="register.php">
        <div class="form-row">
          <div class="form-group">
            <label for="firstName">First Name</label>
            <input type="text" id="firstName" name="first_name" class="form-control" placeholder="Enter first name">
            <div id="firstNameError" class="error-message"></div>
          </div>
          <div class="form-group">
            <label for="lastName">Last Name</label>
            <input type="text" id="lastName" name="last_name" class="form-control" placeholder="Enter last name">
            <div id="lastNameError" class="error-message"></div>
          </div>
        </div>
      
        <div class="form-group">
          <label for="email">Email</label>
          <input type="email" id="email" name="email" class="form-control" placeholder="Enter email">
          <div id="emailError" class="error-message"></div>
        </div>
      
        <div class="form-group">
          <label for="phone">Phone Number</label>
          <input type="tel" id="phone" name="phone" class="form-control" placeholder="Enter phone number">
          <div id="phoneError" class="error-message"></div>
        </div>
      
        <div class="form-row">
          <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" class="form-control" placeholder="Create password">
            <div id="passwordError" class="error-message"></div>
          </div>
          <div class="form-group">
            <label for="confirmPassword">Confirm Password</label>
            <input type="password" id="confirmPassword" name="confirm_password" class="form-control" placeholder="Confirm password">
            <div id="confirmPasswordError" class="error-message"></div>
          </div>
        </div>
      
        <div class="form-group">
          <label for="address">Address</label>
          <input type="text" id="address" name="address" class="form-control" placeholder="Enter your address">
        </div>
      
        <!-- Role Selection -->
        <div class="form-group">
          <label for="role">Role</label>
          <select id="role" name="role" class="form-control">
            <option value="">Select Role</option>
            <option value="conductor">Conductor</option>
            <option value="inspector">Inspector</option>
            <option value="admin">Admin</option>
          </select>
          <div id="roleError" class="error-message"></div>
        </div>
      
        <div class="terms">
          <input type="checkbox" id="terms" name="terms">
          <label for="terms">I agree to the Terms and Conditions</label>
          <div id="termsError" class="error-message"></div>
        </div>
      
        <button type="submit" class="btn">Register Now</button>
      
        <a href="login - conductor.html" class="login-link">Already have an account? Login</a>
      </form>
      
    </div>
  </div>

  <script>
    document.getElementById('registrationForm').addEventListener('submit', function(e) {
      e.preventDefault();

      document.querySelectorAll('.error-message').forEach(el => el.style.display = 'none');
      document.getElementById('successMessage').style.display = 'none';

      const firstName = document.getElementById('firstName').value.trim();
      const lastName = document.getElementById('lastName').value.trim();
      const email = document.getElementById('email').value.trim();
      const phone = document.getElementById('phone').value.trim();
      const password = document.getElementById('password').value;
      const confirmPassword = document.getElementById('confirmPassword').value;
      const role = document.getElementById('role').value;
      const termsChecked = document.getElementById('terms').checked;

      let isValid = true;

      if (!firstName) {
        document.getElementById('firstNameError').textContent = 'First name is required';
        document.getElementById('firstNameError').style.display = 'block';
        isValid = false;
      }
      if (!lastName) {
        document.getElementById('lastNameError').textContent = 'Last name is required';
        document.getElementById('lastNameError').style.display = 'block';
        isValid = false;
      }
      if (!email) {
        document.getElementById('emailError').textContent = 'Email is required';
        document.getElementById('emailError').style.display = 'block';
        isValid = false;
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        document.getElementById('emailError').textContent = 'Please enter a valid email';
        document.getElementById('emailError').style.display = 'block';
        isValid = false;
      }
      if (!phone) {
        document.getElementById('phoneError').textContent = 'Phone number is required';
        document.getElementById('phoneError').style.display = 'block';
        isValid = false;
      } else if (!/^[0-9]{10,15}$/.test(phone)) {
        document.getElementById('phoneError').textContent = 'Please enter a valid phone number';
        document.getElementById('phoneError').style.display = 'block';
        isValid = false;
      }
      if (!password) {
        document.getElementById('passwordError').textContent = 'Password is required';
        document.getElementById('passwordError').style.display = 'block';
        isValid = false;
      } else if (password.length < 8) {
        document.getElementById('passwordError').textContent = 'Password must be at least 8 characters';
        document.getElementById('passwordError').style.display = 'block';
        isValid = false;
      }
      if (password !== confirmPassword) {
        document.getElementById('confirmPasswordError').textContent = 'Passwords do not match';
        document.getElementById('confirmPasswordError').style.display = 'block';
        isValid = false;
      }
      if (!role) {
        document.getElementById('roleError').textContent = 'Role is required';
        document.getElementById('roleError').style.display = 'block';
        isValid = false;
      }
      if (!termsChecked) {
        document.getElementById('termsError').textContent = 'You must accept the terms and conditions';
        document.getElementById('termsError').style.display = 'block';
        isValid = false;
      }

      if (isValid) {
        document.getElementById('successMessage').textContent = 'Registration successful! Welcome to Donsal\'s Express Corporation.';
        document.getElementById('successMessage').style.display = 'block';
        document.getElementById('registrationForm').reset();
        document.getElementById('successMessage').scrollIntoView({ behavior: 'smooth' });
      }
    });

    document.getElementById('confirmPassword').addEventListener('input', function() {
      const password = document.getElementById('password').value;
      const confirmPassword = this.value;

      if (password && confirmPassword && password !== confirmPassword) {
        document.getElementById('confirmPasswordError').textContent = 'Passwords do not match';
        document.getElementById('confirmPasswordError').style.display = 'block';
      } else {
        document.getElementById('confirmPasswordError').style.display = 'none';
      }
    });
  </script>
</body>
</html>
