<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Donsal's Portal Login</title>
  <style>
    * {
      padding: 0;
      margin: 0;
      font-family: Arial, sans-serif;
    }
    body {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      background: orange; /* Gradient from light blue to dark blue */
      position: relative;
    }
    .back-button {
      position: absolute;
      top: 20px;
      left: 20px;
      background-color: white;
      color: orange;
      border: none;
      padding: 8px 16px;
      border-radius: 20px;
      font-weight: bold;
      cursor: pointer;
      z-index: 1;
      text-decoration: none;
      font-size: 14px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    }
    .back-button:hover {
      background-color: #ffe0b3;
    }
    .container {
      padding: 0;
      margin: 0;
      display: flex;
      width: 80%;
      max-width: 900px;
      background: rgba(255, 255, 255, 0.95);
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      overflow: hidden;
      z-index: 1;
      position: relative;
    }
    .left-panel {
      flex: 1;
      padding: 20px;
      text-align: center;
    }
    .left-panel .logo {
      width: 150px;
    }
    .left-panel h1 {
      font-size: 20px;
      color: #333;
    }
    .right-panel {
      flex: 1;
      padding: 40px;
      background: #fff;
    }
    h2 {
      text-align: center;
      margin-bottom: 20px;
    }
    .input-group {
      margin-bottom: 15px;
      position: relative;
    }
    input[type="text"],
    input[type="password"] {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    .captcha {
      display: flex;
      align-items: center;
      margin-bottom: 15px;
    }
    .btn {
      width: 100%;
      padding: 10px;
      background: #007bff;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-weight: bold;
    }
    .btn:hover {
      background: #0056b3;
    }
    .forgot-password {
      display: block;
      text-align: center;
      margin-top: 10px;
      text-decoration: none;
      color: #007bff;
    }
    .error-message {
      color: #dc3545;
      font-size: 12px;
      margin-top: 5px;
      display: none;
    }
    .success-message {
      color: #28a745;
      text-align: center;
      margin-bottom: 15px;
      display: none;
    }
    .loading {
      display: inline-block;
      width: 20px;
      height: 20px;
      border: 3px solid rgba(255,255,255,.3);
      border-radius: 50%;
      border-top-color: #fff;
      animation: spin 1s ease-in-out infinite;
      margin-left: 10px;
    }
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
  </style>
</head>
<body>
  
  <!-- Removed the background corner div -->
  <a href="landingpage.php" class="back-button">← Back</a>

  <div class="container">
    <div class="left-panel">
      <img src="logo.png" alt="donsal" class="logo">
      <h1>Welcome to Donsal's Express Corporation Portal!</h1>
    </div>
    <div class="right-panel">
      <h2>Conductor</h2>
      <div id="successMessage" class="success-message"></div>
      <form id="loginForm">
        <div class="input-group">
          <input type="text" id="email" placeholder="Email" required>
          <div id="emailError" class="error-message"></div>
        </div>
        <div class="input-group">
          <input type="password" id="password" placeholder="Password" required>
          <div id="passwordError" class="error-message"></div>
        </div>
        <div class="captcha">
          <input type="checkbox" id="captcha">
          <label for="captcha">I'm not a robot</label>
          <div id="captchaError" class="error-message"></div>
        </div>
        <button type="submit" class="btn" id="submitBtn">Sign In</button>
        <a href="#" class="forgot-password">Forgot Password?</a>
      </form>
    </div>
  </div>

  <script>
    document.getElementById('loginForm').addEventListener('submit', function(e) {
      e.preventDefault();
      
      document.querySelectorAll('.error-message').forEach(el => {
        el.style.display = 'none';
      });
      
      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value;
      const captchaChecked = document.getElementById('captcha').checked;
      
      let isValid = true;
      
      if (!email) {
        document.getElementById('emailError').textContent = 'Email is required';
        document.getElementById('emailError').style.display = 'block';
        isValid = false;
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        document.getElementById('emailError').textContent = 'Please enter a valid email';
        document.getElementById('emailError').style.display = 'block';
        isValid = false;
      }
      
      if (!password) {
        document.getElementById('passwordError').textContent = 'Password is required';
        document.getElementById('passwordError').style.display = 'block';
        isValid = false;
      } else if (password.length < 6) {
        document.getElementById('passwordError').textContent = 'Password must be at least 6 characters';
        document.getElementById('passwordError').style.display = 'block';
        isValid = false;
      }
      
      if (!captchaChecked) {
        document.getElementById('captchaError').textContent = 'Please verify you are not a robot';
        document.getElementById('captchaError').style.display = 'block';
        isValid = false;
      }
      
      if (isValid) {
        const submitBtn = document.getElementById('submitBtn');
        submitBtn.disabled = true;
        submitBtn.innerHTML = 'Signing In <span class="loading"></span>';
        
        setTimeout(() => {
          document.getElementById('successMessage').textContent = 'Login successful! Redirecting...';
          document.getElementById('successMessage').style.display = 'block';
          
          submitBtn.disabled = false;
          submitBtn.textContent = 'Sign In';
          
          // window.location.href = 'dashboard.html';
        }, 1500);
      }
    });

    document.getElementById('password').addEventListener('dblclick', function() {
      this.type = this.type === 'password' ? 'text' : 'password';
    });
  </script>

</body>
</html>
